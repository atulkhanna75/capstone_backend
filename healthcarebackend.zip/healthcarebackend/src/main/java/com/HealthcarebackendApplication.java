package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthcarebackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthcarebackendApplication.class, args);
	}

}
